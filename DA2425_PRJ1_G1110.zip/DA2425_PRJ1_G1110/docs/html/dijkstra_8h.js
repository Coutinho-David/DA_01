var dijkstra_8h =
[
    [ "alternativeDrivingRoute", "dijkstra_8h.html#a5869c5befc93a78ad396fe03fd68c053", null ],
    [ "bestAndAlternativeDrivingRoute", "dijkstra_8h.html#a4d24d6a07d6e8f5a5be53ce76de4a0ad", null ],
    [ "bestDrivingRoute", "dijkstra_8h.html#aa10bd97713670c3bf2f6f14f19b2ac57", null ],
    [ "dijkstra_driving", "dijkstra_8h.html#a9d799af5f93fc7ff08f75e65b9df75f6", null ],
    [ "dijkstra_walking", "dijkstra_8h.html#a56a6f3cff304c83a461eff536d8f91b8", null ],
    [ "relax_driving", "dijkstra_8h.html#ac6c9b9be80fd9b3831e06e4ebdf1d0e0", null ],
    [ "relax_walking", "dijkstra_8h.html#aa1dab36a3833b3f0b1e578bdef35a1e0", null ],
    [ "restrictedDrivingRoute", "dijkstra_8h.html#a9b96325baa225a6df1b985fa04acb3ee", null ]
];