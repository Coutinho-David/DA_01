var structDistanceData =
[
    [ "CODE1", "structDistanceData.html#a953518a8553d678e9752ce6299bbfbf5", null ],
    [ "CODE2", "structDistanceData.html#a0fec611f60d81d7d698557a58887fcb0", null ],
    [ "Driving", "structDistanceData.html#ac84ce803234eba5e1f9b227385cb939b", null ],
    [ "Walking", "structDistanceData.html#ad6246d809a895ee48ddf52b7a794c4ab", null ]
];