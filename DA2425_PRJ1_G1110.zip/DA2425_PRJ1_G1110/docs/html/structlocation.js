var structlocation =
[
    [ "CODE", "structlocation.html#a3a5d5d3ecb567f07e09738cbd6cb35cc", null ],
    [ "Id", "structlocation.html#a25ec130eaf6d3ffabd1944464eefaf12", null ],
    [ "location", "structlocation.html#a7f8fd90788eca471b818de436b68bf40", null ],
    [ "parking", "structlocation.html#adb2a1c06c0c3e8527142ca30860b3749", null ]
];