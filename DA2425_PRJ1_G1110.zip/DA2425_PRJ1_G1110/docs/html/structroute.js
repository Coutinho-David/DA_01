var structroute =
[
    [ "drivingPath", "structroute.html#aaad92a185db0a28e47cbedc1c8769415", null ],
    [ "drivingTime", "structroute.html#acb85d4df261a5038552fd770c9dbaf90", null ],
    [ "parkNode", "structroute.html#ab36bafe711f11bd06ea66b6ecfd2c409", null ],
    [ "totalTime", "structroute.html#ad5aa7dcea197ec94e49e228b9604fc92", null ],
    [ "walkingPath", "structroute.html#a2e5fab4c98cacfdd410fd1c308b0f7e6", null ],
    [ "walkingTime", "structroute.html#a7d3b00a22bc7ca51b69893d95c657084", null ]
];