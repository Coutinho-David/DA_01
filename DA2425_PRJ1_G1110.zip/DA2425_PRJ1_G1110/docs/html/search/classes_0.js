var searchData=
[
  ['distancedata_0',['DistanceData',['../structDistanceData.html',1,'']]]
];
