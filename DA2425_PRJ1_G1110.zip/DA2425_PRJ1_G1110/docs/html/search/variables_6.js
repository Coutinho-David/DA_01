var searchData=
[
  ['num_0',['num',['../classVertex.html#aeb941bcd51ef71c6101e02eaed1cae12',1,'Vertex']]]
];
