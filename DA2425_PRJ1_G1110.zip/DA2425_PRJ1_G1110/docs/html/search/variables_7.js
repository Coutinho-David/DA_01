var searchData=
[
  ['orig_0',['orig',['../classEdge.html#a4510c31e0479f9d25f6e35d086887192',1,'Edge']]]
];
