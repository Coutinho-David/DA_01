var searchData=
[
  ['location_0',['location',['../structlocation.html',1,'']]]
];
